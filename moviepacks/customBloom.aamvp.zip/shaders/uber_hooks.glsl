// uber_hooks.glsl — customBloom moviepack
//
// Emissive hooks tuned for strong bloom on cycles, cycle walls, and zones.
// All other components are passthrough (no glow).

vec4 hookSky(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec4 hookFloor(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec4 hookRimWall(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec4 hookCycleWall(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec4 hookCycle(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{
    return color;
}

vec4 hookZone(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec4 hookEffects(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

// --- Emissive hooks: drive bloom for cycles, walls, zones ---

vec3 hookCycleEmissive(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{
    return color.rgb;
}

vec3 hookCycleWallEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color.rgb * 0.8;
}

vec3 hookZoneEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color.rgb * 0.6;
}
