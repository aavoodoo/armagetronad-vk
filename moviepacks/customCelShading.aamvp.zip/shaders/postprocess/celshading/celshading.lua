-- Single-pass cel-shading: reads scene color + emissive mask.
-- Emissive marks which pixels are cycles/walls (from uber hooks).
-- Only marked pixels get posterized + outlined.

effect:pass("celshading", "SWAPCHAIN")
effect:sampler(0, "SCENE_COLOR")
effect:sampler(1, "SCENE_EMISSIVE")
effect:sampler(2, "SCENE_DEPTH")

effect:param_int  ("bands",          0, 3,     2,   6,    "Number of shading bands")
effect:param_float("edge_threshold", 0, 0.001, 0.0, 0.02, "Depth edge detection sensitivity")
effect:param_float("edge_thickness", 1, 2.5,   0.5, 6.0,  "Outline thickness in pixels")
effect:param_float("saturation",     2, 1.5,   0.5, 3.0,  "Color saturation boost")
