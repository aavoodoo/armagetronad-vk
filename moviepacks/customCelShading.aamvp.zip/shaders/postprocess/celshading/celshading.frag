#version 450
// Cel-shading post-process: posterize colors + draw ink outlines.
// Only pixels marked in the emissive buffer (cycles, cycle walls) are affected.
// The rest of the scene passes through unchanged.

layout(set = 0, binding = 0) uniform sampler2D uSceneColor;
layout(set = 0, binding = 1) uniform sampler2D uSceneEmissive;
layout(set = 0, binding = 2) uniform sampler2D uSceneDepth;

#include "postprocess_params.glsl"

layout(push_constant) uniform PushConstants {
    vec2  uResolution;
    float uTime;
    float _pad;
    vec4  uArenaBBox;
} pc;

layout(location = 0) in  vec2 vTexCoord;
layout(location = 0) out vec4 fragColor;

// Parameter slot assignments (must match celshading.meta):
#define P_BANDS         IP(0)
#define P_EDGE_THRESH   FP(0)
#define P_EDGE_THICK    FP(1)
#define P_SATURATION    FP(2)

// Posterize a color into N discrete brightness bands
vec3 posterize(vec3 col, int bands) {
    float fb = float(bands);
    float lum = dot(col, vec3(0.299, 0.587, 0.114));
    float stepped = floor(lum * fb + 0.5) / fb;
    return col * (stepped / max(lum, 0.001));
}

// Boost saturation
vec3 saturate_col(vec3 col, float amount) {
    float grey = dot(col, vec3(0.299, 0.587, 0.114));
    return mix(vec3(grey), col, amount);
}

void main()
{
    vec2 texel = 1.0 / pc.uResolution;
    vec4 sceneColor = texture(uSceneColor, vTexCoord);
    vec4 emissive = texture(uSceneEmissive, vTexCoord);

    // Emissive alpha > 0 means this pixel is marked for cel-shading
    float mask = clamp(emissive.a * 10.0, 0.0, 1.0);

    if (mask < 0.01) {
        // Not marked — pass through unchanged (preserves floor, sky, etc.)
        // Sample depth for macOS z-fighting prevention (same as passthrough)
        float depth = texture(uSceneDepth, vTexCoord).r;
        fragColor = vec4(sceneColor.rgb, sceneColor.a * (1.0 - 1.0/1024.0) + depth * (1.0/1024.0));
        return;
    }

    // --- Cel-shading on marked pixels ---

    // 1. Posterize colors
    vec3 col = posterize(sceneColor.rgb, P_BANDS);
    col = saturate_col(col, P_SATURATION);

    // 2. Edge detection using depth buffer (Sobel-like)
    float thickness = P_EDGE_THICK;
    float dc = texture(uSceneDepth, vTexCoord).r;
    float dl = texture(uSceneDepth, vTexCoord + vec2(-texel.x * thickness, 0.0)).r;
    float dr = texture(uSceneDepth, vTexCoord + vec2( texel.x * thickness, 0.0)).r;
    float du = texture(uSceneDepth, vTexCoord + vec2(0.0, -texel.y * thickness)).r;
    float dd = texture(uSceneDepth, vTexCoord + vec2(0.0,  texel.y * thickness)).r;

    float depthEdge = abs(dl - dr) + abs(du - dd);

    // 3. Edge detection using emissive mask (silhouette where mask changes)
    float ml = texture(uSceneEmissive, vTexCoord + vec2(-texel.x * thickness, 0.0)).a;
    float mr = texture(uSceneEmissive, vTexCoord + vec2( texel.x * thickness, 0.0)).a;
    float mu = texture(uSceneEmissive, vTexCoord + vec2(0.0, -texel.y * thickness)).a;
    float md = texture(uSceneEmissive, vTexCoord + vec2(0.0,  texel.y * thickness)).a;

    float maskEdge = abs(ml - mr) + abs(mu - md);

    // Combine edges: depth edges for surface detail, mask edges for silhouettes
    float edge = max(
        smoothstep(P_EDGE_THRESH, P_EDGE_THRESH * 3.0, depthEdge),
        smoothstep(0.1, 0.3, maskEdge)
    );

    // 4. Draw black ink outline
    col = mix(col, vec3(0.0), edge);

    // Sample depth for macOS z-fighting prevention
    fragColor = vec4(col, sceneColor.a * (1.0 - 1.0/1024.0) + dc * (1.0/1024.0));
}
