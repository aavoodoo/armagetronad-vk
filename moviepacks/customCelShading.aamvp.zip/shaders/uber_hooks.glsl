// uber_hooks.glsl — customCelShading moviepack
//
// Emissive hooks mark cycles and cycle walls for the PP cel-shading pass.
// The PP shader uses emissive alpha > 0 as a mask.
// Everything else is passthrough.

vec4 hookSky(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookFloor(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookRimWall(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookCycleWall(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookCycle(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{ return color; }

vec4 hookZone(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookEffects(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

// Mark cycles for cel-shading (emissive = scene color, alpha = mask)
vec3 hookCycleEmissive(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{
    return color.rgb;
}

// Mark cycle walls for cel-shading
vec3 hookCycleWallEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color.rgb;
}

// Zones: no cel-shading
vec3 hookZoneEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return vec3(0.0);
}

vec3 hookRimWallEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{ return vec3(0.0); }
