// uber_hooks.glsl — customMSDFTexture moviepack
//
// Renders rim walls using MSDF textures with 3-color compositing.
// MSDF: multi-channel signed distance field — take median of R,G,B for distance.
// Uses fwidth(d) for pixel-perfect anti-aliasing.

const float SDF_OUTLINE_WIDTH   = 0.3;
const vec3  SDF_INSIDE_COLOR    = vec3(0.4, 0.0, 0.6);    // purple (inside shapes)
const vec3  SDF_OUTLINE_COLOR   = vec3(0.55, 0.55, 0.7);  // light blue-grey outline
const vec3  SDF_OUTSIDE_COLOR   = vec3(0.05, 0.02, 0.15); // dark navy blue (background)

// MSDF median: reconstruct single-channel distance from multi-channel SDF
float msdfMedian(vec3 msd) {
    return max(min(msd.r, msd.g), min(max(msd.r, msd.g), msd.b));
}

vec4 hookSky(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec4 hookFloor(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec4 hookRimWall(vec4 color, vec2 texCoord, vec3 modelPos)
{
    vec3 msd = texture(uTexture, texCoord).rgb;
    float sd = msdfMedian(msd);

    // Compute screenPxRange from texCoord derivatives (msdfgen recommended approach).
    // pxRange = the distance field range in source texture pixels (msdfgen -pxrange).
    // fwidth(texCoord) is safe — always smooth, unlike fwidth(d) which has MSDF discontinuities.
    const float pxRange = 4.0;  // must match the msdfgen -pxrange used to generate the textures
    vec2 sz = vec2(textureSize(uTexture, 0));
    vec2 unitRange = vec2(pxRange) / sz;
    vec2 screenTexSize = vec2(1.0) / fwidth(texCoord);
    float screenPxRange = max(0.5 * dot(unitRange, screenTexSize), 1.0);

    float d = screenPxRange * (sd - 0.5);

    float insideAlpha  = clamp(d + 0.5, 0.0, 1.0);
    float outlineAlpha = clamp(d + SDF_OUTLINE_WIDTH * screenPxRange + 0.5, 0.0, 1.0);

    // Composite: outside → outline → inside
    vec3 rgb = mix(SDF_OUTSIDE_COLOR, SDF_OUTLINE_COLOR, outlineAlpha);
    rgb = mix(rgb, SDF_INSIDE_COLOR, insideAlpha);

    return vec4(rgb, color.a);
}

vec4 hookCycleWall(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec4 hookCycle(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{
    return color;
}

vec4 hookZone(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec4 hookEffects(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color;
}

vec3 hookCycleEmissive(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{
    return color.rgb;
}

vec3 hookCycleWallEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color.rgb * 0.8;
}

vec3 hookZoneEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{
    return color.rgb * 0.6;
}

vec3 hookRimWallEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{ return vec3(0.0); }
