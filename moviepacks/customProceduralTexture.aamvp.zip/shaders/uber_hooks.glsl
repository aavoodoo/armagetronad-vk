// uber_hooks.glsl — customProceduralTexture moviepack
//
// Neon squares with brick-like offset pattern on the floor.

// Render one neon square layer at a given depth below the floor
vec3 neonLayer(vec2 worldPos, vec2 camXY, float camH, float depth, float cellSize) {
    float squareSize = 0.075;
    float lineWidth = 0.006;

    // Per-fragment parallax (tangent space = world space for flat floor).
    // View vector from fragment to camera, then offset UVs by V.xy/V.z * depth.
    // Tangent-space view vector (fragment → camera), negate XY for correct parallax
    vec3 V = vec3(camXY, camH) - vec3(worldPos, 0.0);
    float vz = sign(V.z) * max(abs(V.z), 0.3);
    vec2 deepPos = worldPos - V.xy / vz * depth;

    // World to grid coordinates
    vec2 gridPos = deepPos / cellSize;

    // Brick offset: shift every other row by half a cell
    float row = floor(gridPos.y);
    if (mod(row, 2.0) > 0.5)
        gridPos.x += 0.5;

    vec2 cellID = floor(gridPos);
    vec2 cell = fract(gridPos) - 0.5;

    float d = max(abs(cell.x), abs(cell.y));

    float outline = smoothstep(squareSize + lineWidth, squareSize, d)
                  - smoothstep(squareSize, squareSize - lineWidth, d);
    float glow = exp(-abs(d - squareSize) * 50.0) * 0.3;

    float hue = (cellID.x + cellID.y * 0.7) * 0.15;
    vec3 neonCol = 0.5 + 0.5 * cos(6.28318 * (hue + vec3(0.0, 0.33, 0.67)));

    return neonCol * (outline + glow);
}

vec4 hookFloor(vec4 color, vec2 texCoord, vec3 modelPos)
{
    vec2 arenaMin = uArenaBBox.xy;
    vec2 arenaMax = uArenaBBox.zw;
    vec2 arenaSize = arenaMax - arenaMin;
    if (arenaSize.x < 0.01 || arenaSize.y < 0.01)
        return color;

    float cellSize = arenaSize.x / 5.0;
    float camH = max(abs(uCameraPos.z), 0.5);

    // Three layers stacking downward like columns
    const int   NUM_LAYERS    = 26;
    const float LAYER_SPACING = 2.0;   // meters between layers
    const float FADE_RATE     = 0.12;  // exponential dimming per layer

    vec3 result = vec3(0.0);
    for (int i = 0; i < NUM_LAYERS; i++) {
        float layerDepth = float(i + 1) * LAYER_SPACING;
        float fade = exp(-float(i) * FADE_RATE);
        result += neonLayer(modelPos.xy, uCameraPos.xy, camH, layerDepth, cellSize) * fade;
    }
    result = clamp(result, 0.0, 1.0);

    // Blend: neon layers below, floor grid on top
    vec3 mixed = mix(result, color.rgb, 0.35);
    return vec4(mixed, color.a);
}

// --- All other hooks: passthrough ---

vec4 hookSky(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookRimWall(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookCycleWall(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookCycle(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{ return color; }

vec4 hookZone(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookEffects(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec3 hookCycleEmissive(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{ return color.rgb; }

vec3 hookCycleWallEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color.rgb * 0.8; }

vec3 hookZoneEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color.rgb * 0.6; }
