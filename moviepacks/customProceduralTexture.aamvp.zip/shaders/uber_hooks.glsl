// uber_hooks.glsl — customProceduralTexture moviepack
//
// Floor:    Neon parallax squares with brick-offset pattern
// Rim wall: Animated glowing tile grid (Shadertoy-style)

//=============================================================================
// Utility
//=============================================================================

float tileHash(vec2 p)
{
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

//=============================================================================
// Floor: neon parallax layers
//=============================================================================

vec3 neonLayer(vec2 worldPos, vec2 camXY, float camH, float depth, float cellSize) {
    float squareSize = 0.075;
    float lineWidth = 0.006;

    vec3 V = vec3(camXY, camH) - vec3(worldPos, 0.0);
    float vz = sign(V.z) * max(abs(V.z), 0.3);
    vec2 deepPos = worldPos - V.xy / vz * depth;

    vec2 gridPos = deepPos / cellSize;

    float row = floor(gridPos.y);
    if (mod(row, 2.0) > 0.5)
        gridPos.x += 0.5;

    vec2 cellID = floor(gridPos);
    vec2 cell = fract(gridPos) - 0.5;

    float d = max(abs(cell.x), abs(cell.y));

    float outline = smoothstep(squareSize + lineWidth, squareSize, d)
                  - smoothstep(squareSize, squareSize - lineWidth, d);
    float glow = exp(-abs(d - squareSize) * 50.0) * 0.3;

    float hue = (cellID.x + cellID.y * 0.7) * 0.15;
    vec3 neonCol = 0.5 + 0.5 * cos(6.28318 * (hue + vec3(0.0, 0.33, 0.67)));

    return neonCol * (outline + glow);
}

vec4 hookFloor(vec4 color, vec2 texCoord, vec3 modelPos)
{
    vec2 arenaMin = uArenaBBox.xy;
    vec2 arenaMax = uArenaBBox.zw;
    vec2 arenaSize = arenaMax - arenaMin;
    if (arenaSize.x < 0.01 || arenaSize.y < 0.01)
        return color;

    float cellSize = arenaSize.x / 5.0;
    float camH = max(abs(uCameraPos.z), 0.5);

    const int   NUM_LAYERS    = 8;
    const float LAYER_SPACING = 2.0;
    const float FADE_RATE     = 0.12;

    vec3 result = vec3(0.0);
    for (int i = 0; i < NUM_LAYERS; i++) {
        float layerDepth = float(i + 1) * LAYER_SPACING;
        float fade = exp(-float(i) * FADE_RATE);
        result += neonLayer(modelPos.xy, uCameraPos.xy, camH, layerDepth, cellSize) * fade;
    }
    result = clamp(result, 0.0, 1.0);

    vec3 mixed = mix(result, color.rgb, 0.35);

    // Subtle white tint on floor grid lines (GRID_SIZE_MOVIEPACK = 2.0)
    vec2 gridDist = abs(fract(modelPos.xy / 2.0 + 0.5) - 0.5) * 2.0;
    float dGrid = min(gridDist.x, gridDist.y);
    float gridLine = 1.0 - smoothstep(0.0, 0.06, dGrid);
    mixed = mix(mixed, vec3(1.0), gridLine * 0.12);

    return vec4(mixed, color.a);
}

//=============================================================================
// Rim wall: animated glowing tiles
//=============================================================================

vec4 hookRimWall(vec4 color, vec2 texCoord, vec3 modelPos)
{
    const float TIMESCALE = 0.25;
    const float TILE_SIZE = 8.0;
    const vec3  TILE_COLOR = vec3(0.7, 1.6, 2.8);

    // World-space tile grid.
    // For axis-aligned rim walls, (x+y) varies along the wall, z is height.
    vec2 uv = vec2(modelPos.x + modelPos.y, modelPos.z) / TILE_SIZE;

    // Per-tile noise (3 hashes summed — replaces iChannel0 texture)
    vec2 tileID = floor(uv);
    float n = tileHash(tileID)
            + tileHash(tileID + vec2(17.0, 31.0))
            + tileHash(tileID + vec2(73.0, 59.0));

    // Animated brightness — each tile pulses at its own phase
    float p = 1.0 - mod(n + uTime * TIMESCALE, 1.0);
    p = min(max(p * 3.0 - 1.8, 0.1), 2.0);

    // Rounded vignette within each tile
    vec2 r = mod(uv, 1.0);
    r = vec2(pow(r.x - 0.5, 2.0), pow(r.y - 0.5, 2.0));
    p *= 1.0 - pow(min(1.0, 12.0 * dot(r, r)), 2.0);

    return vec4(TILE_COLOR * p, 1.0);
}

//=============================================================================
// Passthrough hooks
//=============================================================================

vec4 hookSky(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookCycleWall(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookCycle(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{ return color; }

vec4 hookZone(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

vec4 hookEffects(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color; }

//=============================================================================
// Emissive hooks (bloom contribution)
//=============================================================================

vec3 hookRimWallEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{
    // color is the hookRimWall output (HDR tile color).
    // Feed it into bloom at reduced intensity for a subtle glow.
    return color.rgb * 0.4;
}

vec3 hookCycleEmissive(vec4 color, vec2 texCoord, vec3 modelPos, vec3 normal)
{ return color.rgb; }

vec3 hookCycleWallEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color.rgb * 0.8; }

vec3 hookZoneEmissive(vec4 color, vec2 texCoord, vec3 modelPos)
{ return color.rgb * 0.6; }
